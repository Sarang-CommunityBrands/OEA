# OEA setup
This is the current bash-based setup for the core OEA set of Azure resources.

Refer to the [setup section](https://github.com/microsoft/OpenEduAnalytics#setup) on the repo homepage for info setting up OEA in your Azure subscription.