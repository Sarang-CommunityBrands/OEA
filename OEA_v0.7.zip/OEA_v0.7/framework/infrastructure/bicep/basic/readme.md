# OEA basic setup
This is an early stage example of implementing the OEA setup using Bicep.

We will be building this out to become a complete example that can serve as a solid starting point for your OEA env.