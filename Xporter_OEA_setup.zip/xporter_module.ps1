
function Set-OEA {
    [cmdletbinding()]
    param(
        [string]$subscriptionId,
        [string]$resourceGroup,
		 [string]$keyvaultname,
		  [string]$synapsename,
		  [string]$sparkpoolname
		
    )

#extracting zip files
Expand-Archive -Path $Home/clouddrive/Xporter_OEA_setup.zip?raw=true
#set parameters
$subscription_id = $subscriptionId
$resource_group = $resourceGroup
$keyVaultName = $keyvaultname
$synapseName = $synapsename
$sparkPoolName = $sparkpoolname

#execution
az account set --subscription $subscription_id



$resourceGroup = Get-AzResourceGroup -Name $resource_group


$xporterRelyingPartySecretValue = "one.assembly.education"
$xrpsecureString = ConvertTo-SecureString $xporterRelyingPartySecretValue -AsPlainText -Force
$secretRelyingPartyName = "XporterRelyingParty"
Set-AzKeyVaultSecret -VaultName $keyVaultName -Name $secretRelyingPartyName -SecretValue $xrpsecureString


$xporterRelyingPartySecretSecretValue = "EFC642410CED454FB3DC78D8339EE135"
$xrpssecureString = ConvertTo-SecureString $xporterRelyingPartySecretSecretValue -AsPlainText -Force
$secretRelyingPartySecretName = "XporterRelyingPartySecret"

Set-AzKeyVaultSecret -VaultName $keyVaultName -Name $secretRelyingPartySecretName -SecretValue $xrpssecureString




#setting up OEA python
az synapse notebook import --workspace-name $synapseName --name Xporter_py --spark-pool-name $sparkPoolName --file @$Home/clouddrive/Xporter_py.ipynb
az synapse notebook import --workspace-name $synapseName --name Ingest_schoolinfo --spark-pool-name $sparkPoolName --file @$Home/clouddrive/Ingest_schoolinfo.ipynb
az synapse notebook import --workspace-name $synapseName --name Ingest_students --spark-pool-name $sparkPoolName --file @$Home/clouddrive/Ingest_students.ipynb
az synapse notebook import --workspace-name $synapseName --name Ingest_attendancesummary --spark-pool-name $sparkPoolName --file @$Home/clouddrive/Ingest_attendancesummary.ipynb
az synapse notebook import --workspace-name $synapseName --name Ingest_groups --spark-pool-name $sparkPoolName --file @$Home/clouddrive/Ingest_groups.ipynb
az synapse notebook import --workspace-name $synapseName --name Ingest_HistoricalAttendanceSummary --spark-pool-name $sparkPoolName --file @$Home/clouddrive/Ingest_HistoricalAttendanceSummary.ipynb
az synapse notebook import --workspace-name $synapseName --name Ingest_Ingest_staff --spark-pool-name $sparkPoolName --file @$Home/clouddrive/Ingest_staff.ipynb
az synapse notebook import --workspace-name $synapseName --name Ingest_StudentMembers --spark-pool-name $sparkPoolName --file @$Home/clouddrive/Ingest_StudentMembers.ipynb

#setting up pipelines
az synapse pipeline create --workspace-name $synapseName --name import_from_xporter --file @$Home/clouddrive/import_from_xporter.json
az synapse pipeline create --workspace-name $synapseName --name setup_xporter --file @$Home/clouddrive/setup_xporter.json
az synapse pipeline create --workspace-name $synapseName --name OEA_data_ingestion --file @$Home/clouddrive/OEA_data_ingestion.json

#cleaning the resources
rm -r Xporter_py.ipynb
rm -r Ingest_schoolinfo.ipynb
rm -r Ingest_students.ipynb
rm -r Ingest_attendancesummary.ipynb
rm -r Ingest_groups.ipynb
rm -r Ingest_HistoricalAttendanceSummary.ipynb
rm -r Ingest_staff.ipynb
rm -r Ingest_StudentMembers.ipynb
rm -r import_from_xporter.json
rm -r setup_xporter.json
rm -r OEA_data_ingestion.json
rm -r Xporter_OEA_setup.zip?raw=true
}

# function call
#az login
# 1. parameter subscriptionId 2nd resourceGroup 3rd keyVaultName 4th synapseName 5th spark-pool-name
Set-OEA [your sub] [rg-oea-yoursuffix] [kv-oea-yoursuffix] [syn-oea-yoursuffix] [your sparkpool]